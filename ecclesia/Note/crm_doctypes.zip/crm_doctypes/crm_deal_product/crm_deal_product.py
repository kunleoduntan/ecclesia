# Copyright (c) 2026, Value Impacts Consulting
from frappe.model.document import Document
class CrmDealProduct(Document):
    pass
