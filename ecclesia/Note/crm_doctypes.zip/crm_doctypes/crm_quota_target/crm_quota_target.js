// Copyright (c) 2026, Value Impacts Consulting
frappe.ui.form.on("CRM Quota Target", {
    refresh(frm) {
        // CRM Quota Target controller
    },
});
