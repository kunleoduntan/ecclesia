// Copyright (c) 2026, Value Impacts Consulting
frappe.ui.form.on("CRM Territory", {
    refresh(frm) {
        // CRM Territory controller
    },
});
