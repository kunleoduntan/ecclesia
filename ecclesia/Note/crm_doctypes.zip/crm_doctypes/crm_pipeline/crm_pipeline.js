// Copyright (c) 2026, Value Impacts Consulting
frappe.ui.form.on("CRM Pipeline", {
    refresh(frm) {
        // CRM Pipeline controller
    },
});
