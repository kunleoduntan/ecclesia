# Copyright (c) 2026, Value Impacts Consulting
from frappe.model.document import Document
class CrmDealStakeholder(Document):
    pass
