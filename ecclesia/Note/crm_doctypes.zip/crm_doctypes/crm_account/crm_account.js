// Copyright (c) 2026, Value Impacts Consulting
frappe.ui.form.on("CRM Account", {
    refresh(frm) {
        // CRM Account controller
    },
});
