// Copyright (c) 2026, Value Impacts Consulting
frappe.ui.form.on("CRM Contact", {
    refresh(frm) {
        // CRM Contact controller
    },
});
