# Copyright (c) 2026, Value Impacts Consulting
from frappe.model.document import Document
class CrmDealNote(Document):
    pass
