frappe.ui.form.on('Compliance Liability Ledger', {
    refresh: function(frm) {
        const m = {'Open':'blue','Partially Paid':'orange','Fully Paid':'green','Overdue':'red','Reconciled':'green','Exempt':'grey'};
        frm.page && frm.page.set_indicator(frm.doc.status||'Open', m[frm.doc.status]||'grey');
        if (frm.doc.balance_due > 0) {
            frm.set_df_property('balance_due','description',
                `<span style="color:#DC2626;font-weight:700">₦${parseFloat(frm.doc.balance_due).toLocaleString()} outstanding</span>`);
        }
        if (!frm.is_new()) {
            frm.add_custom_button(__('💳 Allocate Payment'), () => {
                frappe.prompt([
                    { label:'Payment Entry', fieldname:'pay', fieldtype:'Link', options:'Payment Entry', reqd:1 },
                    { label:'Amount (₦)', fieldname:'amount', fieldtype:'Currency', reqd:1 }
                ], v => {
                    frappe.call({ method:'ecclesia.api.compliance.allocation_engine_v2.allocate_payment',
                        args:{ payment_reference:v.pay, obligation_type:frm.doc.obligation_type,
                               company:frm.doc.company, allocated_amount:v.amount,
                               period_label:frm.doc.period_label, mode:'exact' },
                        callback: r => { if(r.message){frappe.show_alert({message:r.message.message,indicator:'green'}); frm.reload_doc();} }
                    });
                });
            }, __('Actions'));
            frm.add_custom_button(__('📁 New Filing'), () => frappe.new_doc('Compliance Filing',{
                compliance_liability:frm.doc.name, obligation_type:frm.doc.obligation_type,
                fiscal_period:frm.doc.period_label, company:frm.doc.company }), __('Actions'));
        }
    }
});
