frappe.ui.form.on('Compliance Exception', {
    refresh: function(frm) {
        const m = { 'Open':'red','Under Review':'orange','Resolved':'green','Escalated':'red','Accepted Risk':'grey' };
        frm.page && frm.page.set_indicator(frm.doc.status||'Open', m[frm.doc.status]||'grey');
        if (frm.doc.related_ledger) frm.add_custom_button(__('📋 View CLL'), () => frappe.set_route('Form','Compliance Liability Ledger',frm.doc.related_ledger), __('Related'));
        if (frm.doc.related_filing) frm.add_custom_button(__('📁 View Filing'), () => frappe.set_route('Form','Compliance Filing',frm.doc.related_filing), __('Related'));
    }
});
