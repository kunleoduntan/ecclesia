frappe.ui.form.on('Compliance Rule', {
    refresh: function(frm) {
        const color = frm.doc.active ? 'green' : 'grey';
        frm.page && frm.page.set_indicator(frm.doc.active ? 'Active' : 'Inactive', color);
        if (!frm.is_new()) {
            frm.add_custom_button(__('📅 Generate Calendar'), () => {
                frappe.prompt([
                    { label:'Company',     fieldname:'company',     fieldtype:'Link', options:'Company', reqd:1, default:frm.doc.company },
                    { label:'Fiscal Year', fieldname:'fiscal_year', fieldtype:'Link', options:'Fiscal Year', reqd:1 }
                ], v => {
                    frappe.call({ method:'ecclesia.api.compliance.v3_dashboard_api.generate_calendar_for_rule',
                        args:{ company:v.company, fiscal_year:v.fiscal_year, rule:frm.doc.name },
                        callback: r => frappe.show_alert({ message:'Calendar entries generated ✅', indicator:'green' }) });
                });
            });
        }
    },
    due_day: function(frm) {
        if (frm.doc.due_day && (frm.doc.due_day < 1 || frm.doc.due_day > 31)) {
            frappe.msgprint({ message:'Due Day must be between 1 and 31', indicator:'red' });
        }
    }
});
