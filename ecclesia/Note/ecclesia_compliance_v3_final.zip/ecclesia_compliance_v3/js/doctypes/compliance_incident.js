frappe.ui.form.on('Compliance Incident', {
    refresh: function(frm) {
        const m = { 'Reported':'blue','Under Investigation':'orange','Remediation':'orange','Resolved':'green','Closed':'grey' };
        const sc= { 'Minor':'grey','Moderate':'orange','Major':'red','Critical':'red' };
        frm.page && frm.page.set_indicator(frm.doc.severity||'Minor', sc[frm.doc.severity]||'grey');
        if (frm.doc.related_cll) frm.add_custom_button(__('📋 View CLL'), () => frappe.set_route('Form','Compliance Liability Ledger',frm.doc.related_cll), __('Related'));
    }
});
