frappe.ui.form.on('Compliance Filing', {
    refresh: function(frm) {
        const m = {'Pending':'grey','Filed':'blue','Late Filed':'orange','Amended':'orange','Rejected':'red'};
        frm.page && frm.page.set_indicator(frm.doc.filing_status||'Pending', m[frm.doc.filing_status]||'grey');
        if (frm.doc.compliance_liability) frm.add_custom_button(__('📋 View CLL'), () => frappe.set_route('Form','Compliance Liability Ledger',frm.doc.compliance_liability), __('Related'));
        if (frm.doc.docstatus===1 && frm.doc.filing_status !== 'Filed') {
            frm.add_custom_button(__('✅ Mark Filed'), () => {
                frappe.prompt([
                    { label:'Filing Date', fieldname:'date', fieldtype:'Date', reqd:1, default:frappe.datetime.get_today() },
                    { label:'Regulatory Reference', fieldname:'ref', fieldtype:'Data', reqd:1 }
                ], v => {
                    frappe.db.set_value('Compliance Filing', frm.doc.name, { filing_date:v.date, filing_status:'Filed', filing_reference:v.ref });
                    frm.reload_doc();
                });
            }, __('Actions'));
        }
    }
});
