// Copyright (c) 2026, Value Impacts Consulting
frappe.ui.form.on('Board Resolution', {
    refresh: function(frm) {
        frm.trigger('setup_buttons');
        frm.trigger('apply_status_color');
        frm.trigger('show_cac_warning');
    },
    meeting_type: function(frm) { frm.trigger('show_cac_warning'); },
    resolution_category: function(frm) { frm.trigger('show_cac_warning'); },

    show_cac_warning: function(frm) {
        const cac_cats = ['Appointment / Removal','Capital','Contracts'];
        if (cac_cats.includes(frm.doc.resolution_category)) {
            frm.set_df_property('cac_filing_required','description',
                '<span style="color:#D97706;font-weight:600">⚠️ This resolution category typically requires a CAC filing within 15 days.</span>');
        } else {
            frm.set_df_property('cac_filing_required','description','');
        }
    },

    apply_status_color: function(frm) {
        const m = {'Pending':'orange','In Progress':'blue','Implemented':'green','Not Applicable':'grey'};
        const c = m[frm.doc.implementation_status] || 'grey';
        frm.page && frm.page.set_indicator(frm.doc.implementation_status || 'Draft', c);
    },

    setup_buttons: function(frm) {
        frm.clear_custom_buttons();
        if (!frm.doc.docstatus) return;
        frm.add_custom_button(__('✅ Mark Implemented'), () => {
            frappe.prompt({ label:'Implementation Date', fieldname:'date', fieldtype:'Date', reqd:1,
                default: frappe.datetime.get_today() }, v => {
                frm.set_value('implementation_date', v.date);
                frm.set_value('implementation_status','Implemented');
                frm.save();
            });
        }, __('Actions'));
        if (frm.doc.cac_filing_required && !frm.doc.cac_filed) {
            frm.add_custom_button(__('📋 Mark CAC Filed'), () => {
                frappe.prompt([
                    { label:'CAC Filing Reference', fieldname:'ref', fieldtype:'Data', reqd:1 },
                    { label:'Filing Date', fieldname:'date', fieldtype:'Date', default: frappe.datetime.get_today() }
                ], v => {
                    frappe.db.set_value('Board Resolution', frm.doc.name,
                        {'cac_filed':1,'cac_filing_reference':v.ref});
                    frm.reload_doc();
                    frappe.show_alert({ message:'CAC filing recorded ✅', indicator:'green' });
                });
            }, __('Actions'));
        }
    }
});
