frappe.ui.form.on('Compliance Task', {
    refresh: function(frm) {
        const m = { 'Not Started':'grey','In Progress':'blue','Completed':'green','Delayed':'orange','Cancelled':'grey' };
        frm.page && frm.page.set_indicator(frm.doc.status||'Not Started', m[frm.doc.status]||'grey');
        if (!frm.is_new() && frm.doc.docstatus===1) {
            frm.add_custom_button(__('✅ Mark Completed'), () => {
                frappe.db.set_value('Compliance Task', frm.doc.name, {
                    status:'Completed', actual_completion: frappe.datetime.get_today()
                }).then(() => frm.reload_doc());
            }, __('Actions'));
        }
        if (frm.doc.linked_ledger) frm.add_custom_button(__('📋 View CLL'), () => frappe.set_route('Form','Compliance Liability Ledger',frm.doc.linked_ledger), __('Related'));
        if (frm.doc.linked_filing) frm.add_custom_button(__('📁 View Filing'), () => frappe.set_route('Form','Compliance Filing',frm.doc.linked_filing), __('Related'));
    }
});
