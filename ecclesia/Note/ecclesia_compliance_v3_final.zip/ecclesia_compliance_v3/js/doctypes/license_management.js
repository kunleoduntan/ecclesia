// Copyright (c) 2026, Value Impacts Consulting
// ecclesia/ecclesia/doctype/license_management/license_management.js

frappe.ui.form.on('License Management', {

    refresh: function(frm) {
        frm.trigger('show_expiry_indicator');
        frm.trigger('setup_buttons');
        frm.trigger('apply_status_color');
        frm.trigger('render_renewal_timeline');
    },

    current_expiry_date: function(frm) {
        frm.trigger('show_expiry_indicator');
    },

    auto_status_update: function(frm) {
        if (frm.doc.auto_status_update) {
            frappe.show_alert({ message: __('Status will be updated automatically based on expiry date'), indicator: 'blue' });
        }
    },

    // ── Expiry indicator ────────────────────────────────────────────────────
    show_expiry_indicator: function(frm) {
        if (!frm.doc.current_expiry_date) return;

        const days  = frappe.datetime.get_diff(frm.doc.current_expiry_date, frappe.datetime.get_today());
        const abs   = Math.abs(days);

        frm.set_value('days_to_expiry', days);

        let msg, bg, fc, border;
        if (days < 0) {
            msg    = `🚨 EXPIRED ${abs} day${abs !== 1 ? 's' : ''} ago — Immediate renewal required`;
            bg     = '#FEE2E2'; fc = '#991B1B'; border = '#DC2626';
        } else if (days === 0) {
            msg    = `🔴 EXPIRES TODAY — Renew immediately`;
            bg     = '#FEE2E2'; fc = '#991B1B'; border = '#DC2626';
        } else if (days <= 7) {
            msg    = `🔴 CRITICAL: Expires in ${days} day${days !== 1 ? 's' : ''}`;
            bg     = '#FEE2E2'; fc = '#991B1B'; border = '#DC2626';
        } else if (days <= 30) {
            msg    = `🟠 URGENT: Expires in ${days} days — begin renewal process`;
            bg     = '#FEF3C7'; fc = '#92400E'; border = '#D97706';
        } else if (days <= 90) {
            msg    = `⚠️ Expires in ${days} days — schedule renewal`;
            bg     = '#FEF3C7'; fc = '#92400E'; border = '#D97706';
        } else {
            msg    = `✅ Valid for ${days} more days`;
            bg     = '#D1FAE5'; fc = '#065F46'; border = '#059669';
        }

        frm.set_df_property('current_expiry_date', 'description',
            `<div style="padding:9px 14px;background:${bg};border-left:4px solid ${border};
             border-radius:8px;color:${fc};font-weight:700;font-size:12px;margin-top:4px">${msg}</div>`
        );

        // Renewal lead time warning
        const renewalDays = frm.doc.renewal_cycle_months
            ? Math.round(frm.doc.renewal_cycle_months * 30 * 0.25)   // 25% of cycle as lead time
            : 90;
        if (days > 0 && days <= renewalDays) {
            frm.set_df_property('renewal_cost', 'description',
                `<span style="color:#D97706;font-size:11px;font-weight:600">
                 ⏰ Renewal should be initiated now (${renewalDays}-day lead time recommended)</span>`
            );
        }
    },

    // ── Status color ────────────────────────────────────────────────────────
    apply_status_color: function(frm) {
        const map = {
            'Active':       'green',
            'Expiring Soon':'orange',
            'Expired':      'red',
            'Under Renewal':'blue',
            'Suspended':    'red',
            'Revoked':      'red',
        };
        const color = map[frm.doc.status] || 'grey';
        frm.page && frm.page.set_indicator(frm.doc.status || '—', color);
    },

    // ── Renewal history timeline ────────────────────────────────────────────
    render_renewal_timeline: function(frm) {
        const history = frm.doc.renewal_history || [];
        if (!history.length) return;

        const items = history.slice().reverse().map((r, i) => `
            <div style="display:flex;align-items:flex-start;gap:12px;padding:10px 0;
                        ${i < history.length - 1 ? 'border-bottom:1px solid var(--border-color)' : ''}">
                <div style="width:10px;height:10px;border-radius:50%;background:#059669;
                            flex-shrink:0;margin-top:4px;box-shadow:0 0 0 3px rgba(5,150,105,.2)"></div>
                <div style="flex:1">
                    <div style="font-size:12px;font-weight:700;color:var(--text-color)">
                        Renewed to: <span style="color:#059669">${r.new_expiry_date || '—'}</span>
                    </div>
                    <div style="font-size:11px;color:var(--text-muted);margin-top:2px">
                        Date: ${r.renewal_date || '—'}
                        ${r.previous_expiry ? ` · Previous: ${r.previous_expiry}` : ''}
                        ${r.renewal_cost ? ` · Cost: ₦${parseFloat(r.renewal_cost).toLocaleString()}` : ''}
                    </div>
                </div>
            </div>`
        ).join('');

        frm.set_df_property('renewal_history', 'description',
            `<div style="padding:10px 14px;background:var(--control-bg);border-radius:8px;margin-bottom:8px">
               <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;
                           color:var(--text-muted);margin-bottom:8px">Renewal History (${history.length})</div>
               ${items}
             </div>`
        );
    },

    // ── Action buttons ──────────────────────────────────────────────────────
    setup_buttons: function(frm) {
        frm.clear_custom_buttons();

        if (frm.is_new()) return;

        // ── Renew License ─────────────────────────────────────────────────
        frm.add_custom_button(__('🔄 Renew License'), function() {
            // Pre-compute suggested new expiry based on renewal cycle
            let suggestedExpiry = '';
            if (frm.doc.current_expiry_date && frm.doc.renewal_cycle_months) {
                const expiry = frappe.datetime.str_to_obj(frm.doc.current_expiry_date);
                expiry.setMonth(expiry.getMonth() + frm.doc.renewal_cycle_months);
                suggestedExpiry = frappe.datetime.obj_to_str(expiry);
            }

            frappe.prompt([
                {
                    label:   __('New Expiry Date'),
                    fieldname: 'new_expiry',
                    fieldtype: 'Date',
                    reqd:    1,
                    default: suggestedExpiry,
                    description: `Suggested based on ${frm.doc.renewal_cycle_months || '—'}-month cycle`
                },
                {
                    label:   __('Renewal Cost (₦)'),
                    fieldname: 'cost',
                    fieldtype: 'Currency',
                    default: frm.doc.renewal_cost || 0
                },
                {
                    label:   __('Payment Entry Reference'),
                    fieldname: 'payment_ref',
                    fieldtype: 'Link',
                    options: 'Payment Entry'
                },
                {
                    label:   __('New License Certificate'),
                    fieldname: 'cert',
                    fieldtype: 'Attach'
                },
                {
                    label:   __('Remarks'),
                    fieldname: 'remarks',
                    fieldtype: 'Small Text'
                }
            ], function(values) {
                frappe.call({
                    method:  'ecclesia.ecclesia.doctype.license_management.license_management.renew_license',
                    args: {
                        license_name:           frm.doc.name,
                        new_expiry_date:        values.new_expiry,
                        renewal_cost:           values.cost,
                        payment_reference:      values.payment_ref,
                        payments_ref:           null,
                        certificate_attachment: values.cert
                    },
                    freeze: true,
                    freeze_message: __('Recording renewal…'),
                    callback: function(r) {
                        if (r.message && r.message.success) {
                            frm.reload_doc();
                            frappe.show_alert({
                                message: __('License renewed to {0} ✅', [values.new_expiry]),
                                indicator: 'green'
                            });
                        }
                    }
                });
            }, __('Renew License'), __('Save Renewal'));

        }, __('Actions'));

        // ── Mark Suspended ────────────────────────────────────────────────
        if (!['Suspended', 'Revoked'].includes(frm.doc.status)) {
            frm.add_custom_button(__('⏸ Suspend License'), function() {
                frappe.confirm(
                    __('Mark this license as Suspended? This will disable auto-status update.'),
                    function() {
                        frappe.db.set_value('License Management', frm.doc.name, {
                            status: 'Suspended',
                            auto_status_update: 0
                        }).then(() => {
                            frm.reload_doc();
                            frappe.show_alert({ message: __('License suspended'), indicator: 'orange' });
                        });
                    }
                );
            }, __('Actions'));
        }

        // ── Mark Under Renewal ────────────────────────────────────────────
        if (frm.doc.status === 'Expiring Soon' || frm.doc.status === 'Expired') {
            frm.add_custom_button(__('🔁 Mark Under Renewal'), function() {
                frappe.db.set_value('License Management', frm.doc.name, 'status', 'Under Renewal')
                    .then(() => {
                        frm.reload_doc();
                        frappe.show_alert({ message: __('Status updated to Under Renewal'), indicator: 'blue' });
                    });
            }, __('Actions'));
        }

        // ── Related records ───────────────────────────────────────────────
        frm.add_custom_button(__('📋 CLL Entry'), function() {
            if (frm.doc.compliance_liability_link) {
                frappe.set_route('Form', 'Compliance Liability Ledger', frm.doc.compliance_liability_link);
            } else {
                frappe.msgprint(__('No CLL entry linked to this license.'));
            }
        }, __('Related'));

        frm.add_custom_button(__('⚠️ Compliance Incidents'), function() {
            frappe.set_route('List', 'Compliance Incident', {
                obligation_type: 'License',
                incident_title:  ['like', `%${frm.doc.license_name}%`]
            });
        }, __('Related'));

        // ── Send manual alert ─────────────────────────────────────────────
        frm.add_custom_button(__('📧 Send Expiry Alert'), function() {
            const days = frm.doc.days_to_expiry;
            if (days === null || days === undefined) {
                frappe.msgprint(__('Please save the record first to compute days to expiry.'));
                return;
            }
            frappe.confirm(
                __('Send an expiry alert email to {0} for {1} ({2} days remaining)?',
                    [frm.doc.assigned_to || frm.doc.alert_email || 'responsible officer',
                     frm.doc.license_name, days]),
                function() {
                    frappe.call({
                        method:  'ecclesia.api.compliance.v3_dashboard_api.send_manual_expiry_alert',
                        args:    { doctype: 'License Management', name: frm.doc.name },
                        callback: function() {
                            frappe.show_alert({ message: __('Alert email sent ✅'), indicator: 'green' });
                        }
                    });
                }
            );
        }, __('Actions'));
    }

});

// ── Renewal history child table ─────────────────────────────────────────────
frappe.ui.form.on('License Renewal History', {
    renewal_history_add: function(frm) {
        // Auto-set previous_expiry from the current record
        const rows = frm.doc.renewal_history || [];
        const last = rows[rows.length - 1];
        if (last && !last.previous_expiry) {
            frappe.model.set_value(last.doctype, last.name, 'previous_expiry', frm.doc.current_expiry_date);
        }
    },
    new_expiry_date: function(frm, cdt, cdn) {
        const row = locals[cdt][cdn];
        if (!row.renewal_date) {
            frappe.model.set_value(cdt, cdn, 'renewal_date', frappe.datetime.get_today());
        }
    }
});
