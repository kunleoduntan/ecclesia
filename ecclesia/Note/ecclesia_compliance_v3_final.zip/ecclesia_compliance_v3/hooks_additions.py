# Copyright (c) 2026, Value Impacts Consulting
# ecclesia/hooks.py — COMPLIANCE MODULE ADDITIONS
# Add / merge these entries into your existing hooks.py
# ─────────────────────────────────────────────────────────────────────────────

# ── App pages ─────────────────────────────────────────────────────────────────
page_js = {
    "compliance-hq": "public/js/compliance_hq.js",
}

# ── DocType JS (custom JS for standard DocTypes) ──────────────────────────────
# Place these files in: ecclesia/public/js/
doctype_js = {
    # v2 compliance (existing)
    "Payments":              "public/js/payments_compliance.js",
    "Salary Slip":           "public/js/salary_slip_compliance.js",
    "Sales Invoice":         "public/js/sales_invoice_compliance.js",
    # v3 new doctypes
    "Corporate Compliance Register": "public/js/doctypes/corporate_compliance_register.js",
    "Board Resolution":              "public/js/doctypes/board_resolution.js",
    "Statutory Register Entry":      "public/js/doctypes/statutory_register_entry.js",
    "Contract Compliance Record":    "public/js/doctypes/contract_compliance_record.js",
    "Data Processing Record":        "public/js/doctypes/data_processing_record.js",
    "Data Breach Register":          "public/js/doctypes/data_breach_register.js",
    "AML KYC Record":                "public/js/doctypes/aml_kyc_record.js",
    "Suspicious Transaction Report": "public/js/doctypes/suspicious_transaction_report.js",
    "Labour Compliance Tracker":     "public/js/doctypes/labour_compliance_tracker.js",
    "Expatriate Permit Register":    "public/js/doctypes/expatriate_permit_register.js",
    "Environmental Compliance Record": "public/js/doctypes/environmental_compliance_record.js",
    "Regulatory Return":             "public/js/doctypes/regulatory_return.js",
    "Whistleblower Report":          "public/js/doctypes/whistleblower_report.js",
    "Conflict of Interest Declaration": "public/js/doctypes/conflict_of_interest_declaration.js",
    "Compliance Training Record":    "public/js/doctypes/compliance_training_record.js",
    "Compliance Training Calendar":  "public/js/doctypes/compliance_training_calendar.js",
    # v2 existing compliance doctypes
    "Compliance Liability Ledger":   "public/js/doctypes/compliance_liability_ledger.js",
    "Compliance Filing":             "public/js/doctypes/compliance_filing.js",
    "License Management":            "public/js/doctypes/license_management.js",
    "Compliance Risk Register":      "public/js/doctypes/compliance_risk_register.js",
    "Compliance Audit":              "public/js/doctypes/compliance_audit.js",
}

# ── Scheduler events ──────────────────────────────────────────────────────────
scheduler_events = {
    "daily": [
        # v2 — statutory liabilities + CLL reconciliation + alerts
        "ecclesia.ecclesia.scheduler.compliance_scheduler_v2.run_daily",
    ],
    "monthly": [
        "ecclesia.ecclesia.scheduler.compliance_scheduler_v2.run_monthly",
    ],
    "yearly": [
        # ITF annual levy generation
        "ecclesia.ecclesia.scheduler.compliance_scheduler_v2.run_yearly",
    ],
}

# ── Doc events ────────────────────────────────────────────────────────────────
doc_events = {

    # ── ERPNext core ──────────────────────────────────────────────────────────
    "Sales Invoice": {
        # Generate VAT liability in CLL on invoice submission
        "on_submit": "ecclesia.api.compliance.liability_engine_v2.generate_vat_liability",
    },
    "Purchase Invoice": {
        # WHT is driven from Payments DocType; log WHT event here
        "on_submit": "ecclesia.api.compliance.liability_engine_v2.log_purchase_invoice_wht",
    },
    "Salary Slip": {
        # Link salary slip to PAYE / Pension / NHF CLL entries
        "on_submit":  "ecclesia.api.compliance.liability_engine_v2.link_salary_slip_to_cll",
    },

    # ── Ecclesia Payments DocType ─────────────────────────────────────────────
    "Payments": {
        # Run CLL allocation engine on payment submission
        "on_submit":  "ecclesia.api.compliance.allocation_engine_v2.on_payments_submit",
        # Reverse allocations on cancellation
        "on_cancel":  "ecclesia.api.compliance.allocation_engine_v2.on_payments_cancel",
    },

    # ── Compliance v3: governance ─────────────────────────────────────────────
    "Board Resolution": {
        "on_submit": "ecclesia.ecclesia.doctype.board_resolution.board_resolution.on_submit",
    },
    "Corporate Compliance Register": {
        "on_submit": "ecclesia.ecclesia.doctype.corporate_compliance_register.corporate_compliance_register.on_submit",
    },

    # ── Compliance v3: data protection ───────────────────────────────────────
    "Data Breach Register": {
        "on_submit": "ecclesia.ecclesia.doctype.data_breach_register.data_breach_register.on_submit",
    },
    "Data Processing Record": {
        "on_submit": "ecclesia.ecclesia.doctype.data_processing_record.data_processing_record.on_submit",
    },

    # ── Compliance v3: AML ────────────────────────────────────────────────────
    "AML KYC Record": {
        "on_submit": "ecclesia.ecclesia.doctype.aml_kyc_record.aml_kyc_record.on_submit",
    },
    "Suspicious Transaction Report": {
        "on_submit": "ecclesia.ecclesia.doctype.suspicious_transaction_report.suspicious_transaction_report.on_submit",
    },

    # ── Compliance v3: labour ─────────────────────────────────────────────────
    "Labour Compliance Tracker": {
        "on_submit": "ecclesia.ecclesia.doctype.labour_compliance_tracker.labour_compliance_tracker.on_submit",
    },

    # ── Compliance v3: industry ───────────────────────────────────────────────
    "Regulatory Return": {
        "on_submit": "ecclesia.ecclesia.doctype.regulatory_return.regulatory_return.on_submit",
    },

    # ── Compliance v3: fraud & integrity ─────────────────────────────────────
    "Whistleblower Report": {
        "on_submit": "ecclesia.ecclesia.doctype.whistleblower_report.whistleblower_report.on_submit",
    },
    "Conflict of Interest Declaration": {
        "on_submit": "ecclesia.ecclesia.doctype.conflict_of_interest_declaration.conflict_of_interest_declaration.on_submit",
    },

    # ── Compliance v3: training ───────────────────────────────────────────────
    "Compliance Training Record": {
        "on_submit": "ecclesia.ecclesia.doctype.compliance_training_record.compliance_training_record.on_submit",
    },
    "Compliance Training Calendar": {
        "on_submit": "ecclesia.ecclesia.doctype.compliance_training_calendar.compliance_training_calendar.on_submit",
    },

    # ── Compliance v3: contracts ──────────────────────────────────────────────
    "Contract Compliance Record": {
        "on_update": "ecclesia.ecclesia.doctype.contract_compliance_record.contract_compliance_record.on_update",
    },

    # ── Compliance v3: environmental ──────────────────────────────────────────
    "Environmental Compliance Record": {
        "on_update": "ecclesia.ecclesia.doctype.environmental_compliance_record.environmental_compliance_record.on_update",
    },

    # ── Ecclesia HR — link documents to compliance ────────────────────────────
    "Company Policy": {
        # When a policy is published, create/update linked Compliance Policy
        "on_submit": "ecclesia.api.compliance.policy_bridge.sync_to_compliance_policy",
    },
}

# ── Whitelisted API methods ───────────────────────────────────────────────────
# All methods decorated with @frappe.whitelist() are auto-discovered.
# Listed here for documentation and IDE support:
#
# LIABILITY ENGINE
#   ecclesia.api.compliance.liability_engine_v2.generate_vat_liability
#   ecclesia.api.compliance.liability_engine_v2.generate_wht_liability
#   ecclesia.api.compliance.liability_engine_v2.generate_payroll_liabilities
#   ecclesia.api.compliance.liability_engine_v2.run_all_liability_generation
#
# ALLOCATION ENGINE
#   ecclesia.api.compliance.allocation_engine_v2.allocate_payment
#   ecclesia.api.compliance.allocation_engine_v2.preview_allocation
#   ecclesia.api.compliance.allocation_engine_v2.reconcile_all_cll
#
# DASHBOARD API
#   ecclesia.api.compliance.compliance_dashboard_api.get_dashboard_summary
#   ecclesia.api.compliance.compliance_dashboard_api.get_cll_list
#   ecclesia.api.compliance.compliance_dashboard_api.run_liability_generation_now
#   ecclesia.api.compliance.compliance_dashboard_api.run_reconciliation_now
#   ecclesia.api.compliance.compliance_dashboard_api.get_ai_compliance_analysis
#
# v3 DOMAIN APIs
#   ecclesia.api.compliance.v3_dashboard_api.get_v3_domain_summary
#   ecclesia.api.compliance.v3_dashboard_api.get_corporate_governance_tab
#   ecclesia.api.compliance.v3_dashboard_api.get_aml_tab
#   ecclesia.api.compliance.v3_dashboard_api.get_ndpr_tab
#   ecclesia.api.compliance.v3_dashboard_api.get_labour_tab
#   ecclesia.api.compliance.v3_dashboard_api.get_environmental_tab
#   ecclesia.api.compliance.v3_dashboard_api.get_industry_tab
#   ecclesia.api.compliance.v3_dashboard_api.get_contracts_tab
#   ecclesia.api.compliance.v3_dashboard_api.get_fraud_tab
#   ecclesia.api.compliance.v3_dashboard_api.get_training_tab
#
# DOCTYPE METHODS
#   ecclesia.ecclesia.doctype.corporate_compliance_register.corporate_compliance_register.get_cac_due_date
#   ecclesia.ecclesia.doctype.corporate_compliance_register.corporate_compliance_register.get_company_register_for_year
#   ecclesia.ecclesia.doctype.statutory_register_entry.statutory_register_entry.get_entries_by_register_type
#   ecclesia.ecclesia.doctype.contract_compliance_record.contract_compliance_record.get_contract_compliance_summary
#   ecclesia.ecclesia.doctype.contract_compliance_record.contract_compliance_record.contracts_expiring_soon
#   ecclesia.ecclesia.doctype.data_processing_record.data_processing_record.get_processing_records_requiring_review
#   ecclesia.ecclesia.doctype.data_breach_register.data_breach_register.get_breach_summary
#   ecclesia.ecclesia.doctype.aml_kyc_record.aml_kyc_record.get_kyc_expiring_soon
#   ecclesia.ecclesia.doctype.aml_kyc_record.aml_kyc_record.get_high_risk_parties
#   ecclesia.ecclesia.doctype.suspicious_transaction_report.suspicious_transaction_report.get_str_summary
#   ecclesia.ecclesia.doctype.labour_and_expatriate.get_expiring_permits
#   ecclesia.ecclesia.doctype.labour_and_expatriate.get_permit_dashboard
#   ecclesia.ecclesia.doctype.labour_and_expatriate.get_labour_trend
#   ecclesia.ecclesia.doctype.environmental_compliance_record.environmental_compliance_record.get_environmental_dashboard
#   ecclesia.ecclesia.doctype.regulatory_return.regulatory_return.get_regulatory_returns_dashboard
#   ecclesia.ecclesia.doctype.whistleblower_report.whistleblower_report.get_whistleblower_summary
#   ecclesia.ecclesia.doctype.conflict_of_interest_declaration.conflict_of_interest_declaration.get_coi_dashboard
#   ecclesia.ecclesia.doctype.compliance_training_record.compliance_training_record.get_training_completion_rate
#   ecclesia.ecclesia.doctype.license_management.license_management.renew_license

# ── Fixtures (data to export/import) ─────────────────────────────────────────
fixtures = [
    {"dt": "Regulatory Authority", "filters": [["module", "=", "Ecclesia"]]},
    {"dt": "Compliance Rule",      "filters": [["module", "=", "Ecclesia"]]},
    {"dt": "Compliance Alert Rule","filters": [["module", "=", "Ecclesia"]]},
    {"dt": "Compliance Period",    "filters": [["module", "=", "Ecclesia"]]},
]

# ── Required apps ─────────────────────────────────────────────────────────────
required_apps = ["frappe", "erpnext"]
