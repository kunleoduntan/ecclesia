# ══════════════════════════════════════════════════════════════════════════════
# regulatory_return.py
# ecclesia/ecclesia/doctype/regulatory_return/regulatory_return.py
# ══════════════════════════════════════════════════════════════════════════════

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import getdate, nowdate, flt, add_days


class RegulatoryReturn(Document):

    def validate(self):
        self._check_late_flag()
        self._validate_title()

    def on_submit(self):
        self._update_status_on_submit()
        self._create_cll_if_penalty()
        self._send_submission_confirmation()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _validate_title(self):
        if not self.return_title:
            self.return_title = f"{self.return_type} — {self.period_covered or ''} — {self.company}"

    def _check_late_flag(self):
        if self.submission_date and self.due_date:
            late = getdate(self.submission_date) > getdate(self.due_date)
            self.late_flag = 1 if late else 0
            if late:
                self.status = "Late Submitted"
                if self.penalty_for_non_filing:
                    self.penalty_incurred = flt(self.penalty_for_non_filing)
                frappe.msgprint(
                    _(f"⚠️ This return was submitted after the due date ({self.due_date}). "
                      f"Penalty of ₦{flt(self.penalty_for_non_filing):,.0f} may be applicable."),
                    indicator="orange", alert=True
                )
        elif not self.submission_date and self.due_date:
            if getdate(self.due_date) < getdate(nowdate()):
                self.status = "Overdue"
                self.late_flag = 1

    def _update_status_on_submit(self):
        if self.submission_date:
            self.db_set("status",
                        "Late Submitted" if self.late_flag else "Submitted")

    def _create_cll_if_penalty(self):
        """If a penalty was incurred, create/update a CLL entry."""
        if not self.penalty_incurred or not self.cll_entry:
            return
        try:
            cll = frappe.get_doc("Compliance Liability Ledger", self.cll_entry)
            if flt(cll.total_liability) < flt(self.penalty_incurred):
                cll.append("source_lines", {
                    "source_doctype": "Regulatory Return",
                    "source_document": self.name,
                    "posting_date": nowdate(),
                    "gross_amount": 0,
                    "liability_amount": flt(self.penalty_incurred),
                    "remarks": f"Late filing penalty for {self.return_type}"
                })
                cll.save(ignore_permissions=True)
        except Exception:
            pass

    def _send_submission_confirmation(self):
        if not self.filed_by:
            return
        email = frappe.db.get_value("Employee", self.filed_by, "company_email")
        if not email:
            return
        frappe.sendmail(
            recipients=[email],
            subject=_(f"Regulatory Return Submitted: {self.return_title}"),
            message=_("""
                <p>Regulatory Return <b>{0}</b> has been submitted.</p>
                <table cellpadding="6" style="font-size:13px">
                  <tr><td><b>Authority:</b></td><td>{1}</td></tr>
                  <tr><td><b>Period:</b></td><td>{2}</td></tr>
                  <tr><td><b>Submission Date:</b></td><td>{3}</td></tr>
                  <tr><td><b>Status:</b></td><td>{4}</td></tr>
                  <tr><td><b>Reference:</b></td><td>{5}</td></tr>
                  {6}
                </table>
                <p><a href="/Form/Regulatory Return/{7}">View Return →</a></p>
            """).format(
                self.return_title, self.authority, self.period_covered or "—",
                self.submission_date or "—", self.status, self.return_reference or "Pending",
                f"<tr><td><b>Penalty:</b></td><td style='color:red'>₦{flt(self.penalty_incurred):,.0f}</td></tr>"
                if self.penalty_incurred else "",
                self.name
            )
        )


@frappe.whitelist()
def get_regulatory_returns_dashboard(company):
    returns = frappe.db.get_all(
        "Regulatory Return",
        filters={"company": company},
        fields=["name","return_title","authority","status","due_date",
                "late_flag","penalty_incurred","industry_category"]
    )
    return {
        "total":     len(returns),
        "overdue":   sum(1 for r in returns if r.status == "Overdue"),
        "late":      sum(1 for r in returns if r.late_flag),
        "pending":   sum(1 for r in returns if r.status in ("Pending","Preparing")),
        "penalty_total": sum(flt(r.penalty_incurred or 0) for r in returns),
        "records":   returns
    }


# ══════════════════════════════════════════════════════════════════════════════
# whistleblower_report.py
# ecclesia/ecclesia/doctype/whistleblower_report/whistleblower_report.py
# ══════════════════════════════════════════════════════════════════════════════

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import nowdate, random_string


class WhistleblowerReport(Document):

    def before_insert(self):
        self._generate_masked_code()
        if not self.received_date:
            self.received_date = nowdate()

    def validate(self):
        self._protect_identity()

    def on_submit(self):
        self._notify_investigators()
        self._raise_compliance_incident_if_critical()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _generate_masked_code(self):
        """Generate a random, non-identifiable report code."""
        if not self.report_code:
            code = "WB-" + random_string(8).upper()
            self.report_code = code

    def _protect_identity(self):
        """Never store identifying information if anonymous."""
        if self.is_anonymous:
            # Clear any accidentally entered identifying details
            if self.alleged_parties and "@" in self.alleged_parties:
                frappe.msgprint(
                    _("Do not include contact details of anonymous reporters in the alleged parties field."),
                    indicator="orange"
                )

    def _notify_investigators(self):
        """Notify assigned investigator and compliance officer — confidentially."""
        emails = []
        if self.assigned_investigator:
            e = frappe.db.get_value("Employee", self.assigned_investigator, "company_email")
            if e:
                emails.append(e)
        co = frappe.db.get_value("Company", self.company, "compliance_officer")
        if co:
            e = frappe.db.get_value("Employee", co, "company_email")
            if e and e not in emails:
                emails.append(e)

        if not emails:
            return

        from ecclesia.ecclesia.compliance_setup.email_templates import (
            render_whistleblower_received, send_compliance_email
        )
        html = render_whistleblower_received(self)
        send_compliance_email(
            recipients=emails,
            subject=f"🔒 [CONFIDENTIAL] Whistleblower Report Received: {self.report_code}",
            html_body=html
        )

    def _raise_compliance_incident_if_critical(self):
        if self.severity not in ("High", "Critical"):
            return
        if self.compliance_incident_ref:
            return
        inc = frappe.new_doc("Compliance Incident")
        inc.incident_title  = f"Whistleblower: {self.report_code} — {self.report_category}"
        inc.incident_date   = self.received_date
        inc.incident_type   = "Fraud" if "Fraud" in self.report_category else "Other"
        inc.severity        = self.severity
        inc.status          = "Under Investigation"
        inc.description     = (f"Whistleblower report {self.report_code}. "
                               f"Category: {self.report_category}. "
                               f"Severity: {self.severity}.")
        if self.assigned_investigator:
            inc.assigned_to = self.assigned_investigator
        inc.insert(ignore_permissions=True)
        self.db_set("compliance_incident_ref", inc.name)


@frappe.whitelist()
def get_whistleblower_summary(company):
    reports = frappe.db.get_all(
        "Whistleblower Report",
        filters={"company": company},
        fields=["status", "severity", "report_category", "outcome"]
    )
    return {
        "total":          len(reports),
        "under_investigation": sum(1 for r in reports if r.status == "Under Investigation"),
        "substantiated":  sum(1 for r in reports if r.outcome and "Substantiated" in r.outcome),
        "critical":       sum(1 for r in reports if r.severity == "Critical"),
        "by_category":    {}
    }


# ══════════════════════════════════════════════════════════════════════════════
# conflict_of_interest_declaration.py
# ecclesia/ecclesia/doctype/conflict_of_interest_declaration/conflict_of_interest_declaration.py
# ══════════════════════════════════════════════════════════════════════════════

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import nowdate, add_days


class ConflictOfInterestDeclaration(Document):

    def before_insert(self):
        self._set_title()
        self._pull_employee_details()

    def validate(self):
        self._set_title()
        self._set_next_review()

    def on_submit(self):
        self._notify_line_manager()
        if self.has_conflict and self.financial_interest:
            self._notify_compliance_officer()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _set_title(self):
        if not self.declaration_title and self.employee and self.declaration_type:
            emp_name = frappe.db.get_value("Employee", self.employee, "employee_name") or self.employee
            self.declaration_title = f"{emp_name} — {self.declaration_type} — {self.declaration_date or nowdate()}"

    def _pull_employee_details(self):
        if self.employee and not self.designation:
            details = frappe.db.get_value(
                "Employee", self.employee,
                ["designation", "department", "company"], as_dict=True
            )
            if details:
                self.designation = details.designation
                if not self.department:
                    self.department = details.department
                if not self.company:
                    self.company = details.company

    def _set_next_review(self):
        if not self.next_review_date:
            self.next_review_date = add_days(self.declaration_date or nowdate(), 365)

    def _notify_line_manager(self):
        """Send review request to line manager."""
        if not self.acknowledged_by:
            # Try to find reporting manager
            manager = frappe.db.get_value("Employee", self.employee, "reports_to")
            if manager:
                self.db_set("acknowledged_by", manager)

        reviewer = self.acknowledged_by
        if not reviewer:
            return
        email = frappe.db.get_value("Employee", reviewer, "company_email")
        if not email:
            return

        from ecclesia.ecclesia.compliance_setup.email_templates import (
            render_coi_review_request, send_compliance_email
        )
        html = render_coi_review_request(self)
        send_compliance_email(
            recipients=[email],
            subject=f"COI Declaration for Review: {self.employee} — {'CONFLICT DECLARED' if self.has_conflict else 'No Conflict'}",
            html_body=html
        )

    def _notify_compliance_officer(self):
        co = frappe.db.get_value("Company", self.company, "compliance_officer")
        if not co:
            return
        email = frappe.db.get_value("Employee", co, "company_email")
        if not email:
            return
        frappe.sendmail(
            recipients=[email],
            subject=_(f"⚠️ Conflict of Interest with Financial Interest: {self.employee}"),
            message=_("""
                <p>A Conflict of Interest declaration has been submitted with a financial interest declared.</p>
                <p><b>Employee:</b> {0}<br>
                <b>Conflict Type:</b> {1}<br>
                <b>Financial Value:</b> ₦{2:,.0f}<br>
                <b>Recusal Required:</b> {3}</p>
                <p><a href="/Form/Conflict of Interest Declaration/{4}">Review Declaration →</a></p>
            """).format(
                self.employee, self.conflict_type or "—",
                float(self.financial_value or 0),
                "YES" if self.recusal_required else "No",
                self.name
            )
        )


@frappe.whitelist()
def get_coi_dashboard(company, fiscal_year=None):
    filters = {"company": company}
    if fiscal_year:
        filters["fiscal_year"] = fiscal_year
    declarations = frappe.db.get_all(
        "Conflict of Interest Declaration",
        filters=filters,
        fields=["name","employee","has_conflict","approval_status","declaration_type","fiscal_year"]
    )
    return {
        "total":          len(declarations),
        "with_conflict":  sum(1 for d in declarations if d.has_conflict),
        "pending_review": sum(1 for d in declarations if d.approval_status == "Pending"),
        "annual":         sum(1 for d in declarations if d.declaration_type == "Annual Declaration")
    }


# ══════════════════════════════════════════════════════════════════════════════
# compliance_training_record.py
# ecclesia/ecclesia/doctype/compliance_training_record/compliance_training_record.py
# ══════════════════════════════════════════════════════════════════════════════

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt, nowdate


class ComplianceTrainingRecord(Document):

    def validate(self):
        self._set_passed()
        self._set_title()

    def on_submit(self):
        self._update_training_calendar()
        self._notify_employee()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _set_title(self):
        if not self.training_title and self.training_category:
            emp_name = frappe.db.get_value("Employee", self.employee, "employee_name") or self.employee
            self.training_title = f"{self.training_category} — {emp_name} — {self.training_date or nowdate()}"

    def _set_passed(self):
        if self.completion_status == "Completed":
            if self.score is not None:
                self.passed = 1 if flt(self.score) >= 70 else 0
            else:
                self.passed = 1
        elif self.completion_status in ("Failed",):
            self.passed = 0

    def _update_training_calendar(self):
        if not self.training_calendar:
            return
        cal = frappe.get_doc("Compliance Training Calendar", self.training_calendar)
        completed = frappe.db.count("Compliance Training Record", {
            "training_calendar": self.training_calendar,
            "completion_status": "Completed",
            "docstatus": 1
        })
        if cal.target_headcount and cal.target_headcount > 0:
            cal.actual_attendees = completed
            cal.actual_completion_pct = round(completed / cal.target_headcount * 100, 1)
            if cal.actual_completion_pct >= 95:
                cal.status = "Completed"
            cal.save(ignore_permissions=True)

    def _notify_employee(self):
        email = frappe.db.get_value("Employee", self.employee, "company_email")
        if not email:
            return
        from ecclesia.ecclesia.compliance_setup.email_templates import (
            render_training_completion, send_compliance_email
        )
        html = render_training_completion(self)
        send_compliance_email(
            recipients=[email],
            subject=f"{'✅ Training Completed' if self.passed else '❌ Training Incomplete'}: {self.training_category}",
            html_body=html
        )


@frappe.whitelist()
def get_training_completion_rate(company, fiscal_year=None):
    filters = {"company": company, "docstatus": 1}
    if fiscal_year:
        pass  # training_date filter
    records = frappe.db.get_all(
        "Compliance Training Record",
        filters=filters,
        fields=["completion_status","training_category","is_mandatory","passed","employee"]
    )
    mandatory = [r for r in records if r.is_mandatory]
    return {
        "total": len(records),
        "mandatory": len(mandatory),
        "mandatory_completed": sum(1 for r in mandatory if r.completion_status == "Completed"),
        "mandatory_completion_pct": round(
            sum(1 for r in mandatory if r.completion_status == "Completed") / len(mandatory) * 100, 1
        ) if mandatory else 0,
        "by_category": {}
    }


# ══════════════════════════════════════════════════════════════════════════════
# compliance_training_calendar.py
# ecclesia/ecclesia/doctype/compliance_training_calendar/compliance_training_calendar.py
# ══════════════════════════════════════════════════════════════════════════════

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import nowdate, flt


class ComplianceTrainingCalendar(Document):

    def validate(self):
        self._compute_completion()
        self._update_participant_count()

    def on_submit(self):
        self.db_set("status", "Scheduled")
        self._send_invites_to_participants()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _update_participant_count(self):
        if self.participants:
            self.actual_attendees = len([
                p for p in self.participants
                if p.completion_status in ("Attended","Passed","Completed")
            ])
            if self.target_headcount and self.target_headcount > 0:
                self.actual_completion_pct = round(
                    self.actual_attendees / self.target_headcount * 100, 1
                )

    def _compute_completion(self):
        if self.participants:
            completed = sum(1 for p in self.participants if p.completion_status in ("Passed","Attended"))
            total = len(self.participants)
            if total > 0:
                self.actual_completion_pct = round(completed / total * 100, 1)
                if self.actual_completion_pct >= flt(self.completion_target_pct or 100):
                    self.status = "Completed"

    def _send_invites_to_participants(self):
        if not self.participants:
            return
        for row in self.participants[:50]:  # cap at 50 to avoid massive sends
            email = frappe.db.get_value("Employee", row.employee, "company_email")
            if not email:
                continue
            frappe.sendmail(
                recipients=[email],
                subject=_(f"Compliance Training Scheduled: {self.training_category}"),
                message=_("""
                    <p>You are enrolled in a mandatory compliance training session.</p>
                    <table cellpadding="6" style="font-size:13px">
                      <tr><td><b>Training:</b></td><td>{0}</td></tr>
                      <tr><td><b>Category:</b></td><td>{1}</td></tr>
                      <tr><td><b>Date:</b></td><td>{2}</td></tr>
                      <tr><td><b>Duration:</b></td><td>{3} hours</td></tr>
                      <tr><td><b>Venue/Mode:</b></td><td>{4}</td></tr>
                      <tr><td><b>Trainer:</b></td><td>{5}</td></tr>
                    </table>
                    <p><b>This is a mandatory compliance requirement.</b>
                    Non-attendance must be approved in advance by your line manager.</p>
                    <p><a href="/Form/Compliance Training Calendar/{6}">View Training Details →</a></p>
                """).format(
                    self.calendar_title, self.training_category,
                    self.scheduled_date, self.duration_hours or "TBD",
                    self.venue or "TBD", self.trainer or "TBD", self.name
                )
            )
