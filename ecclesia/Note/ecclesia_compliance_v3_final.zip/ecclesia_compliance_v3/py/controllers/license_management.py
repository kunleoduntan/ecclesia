# Copyright (c) 2026, Value Impacts Consulting
import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt, nowdate, date_diff

class LicenseManagement(Document):
    def validate(self):
        self._compute_days_to_expiry()
        if self.auto_status_update:
            self._update_status()

    def _compute_days_to_expiry(self):
        if self.current_expiry_date:
            self.days_to_expiry = date_diff(self.current_expiry_date, nowdate())

    def _update_status(self):
        if self.status in ("Suspended","Revoked"):
            return
        days = self.days_to_expiry or 0
        if days < 0:
            self.status = "Expired"
        elif days <= 30:
            self.status = "Expiring Soon"
        else:
            self.status = "Active"


@frappe.whitelist()
def renew_license(license_name, new_expiry_date, renewal_cost=None,
                  payment_reference=None, payments_ref=None, certificate_attachment=None):
    doc = frappe.get_doc("License Management", license_name)
    doc.append("renewal_history", {
        "renewal_date":          nowdate(),
        "previous_expiry":       doc.current_expiry_date,
        "new_expiry_date":       new_expiry_date,
        "renewal_cost":          flt(renewal_cost) if renewal_cost else 0,
        "payment_reference":     payment_reference,
        "payments_ref":          payments_ref,
        "certificate_attachment": certificate_attachment,
    })
    doc.current_expiry_date = new_expiry_date
    doc.status = "Active"
    doc._compute_days_to_expiry()
    doc.save(ignore_permissions=True)
    frappe.db.commit()
    return {"success": True, "message": f"License renewed to {new_expiry_date}"}
