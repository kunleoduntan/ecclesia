# Copyright (c) 2026, Value Impacts Consulting
import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import nowdate

class ComplianceException(Document):
    def before_insert(self):
        if not self.incident_date:
            self.incident_date = nowdate()

    def on_submit(self):
        self._notify_management()

    def _notify_management(self):
        if self.severity not in ("Major","Critical"):
            return
        managers = frappe.db.get_all("Has Role", filters={"role":"Accounts Manager"}, fields=["parent"])
        emails = [frappe.db.get_value("User", m.parent, "email") for m in managers]
        emails = [e for e in emails if e]
        if emails:
            frappe.sendmail(recipients=emails,
                subject=f"[{self.severity}] Compliance Exception: {self.exception_title}",
                message=(f"<b>Type:</b> {self.exception_type}<br><b>Obligation:</b> {self.obligation_type}<br>"
                         f"<b>Impact:</b> ₦{self.financial_impact:,.0f}<br>"
                         f"<a href='/Form/Compliance Exception/{self.name}'>Review Exception</a>"))
