# Copyright (c) 2026, Value Impacts Consulting
# ecclesia/ecclesia/doctype/compliance_liability_ledger/compliance_liability_ledger.py
"""
Compliance Liability Ledger — DocType Controller (v2)
═══════════════════════════════════════════════════════
The statutory sub-ledger. One record per obligation-type per period per company.

Key design decisions (v2):
  - ledger_key is auto-set as: OBLIGATION-MM-YYYY-COMPANYCODE (e.g. VAT-03-2026-ABC)
  - Links to Compliance Period and Fiscal Year for proper time-bucketing
  - total_allocated is sum of Compliance Allocation Line rows (not just child table)
  - status is computed, never manually set
  - Compliance Rule link allows data-driven penalty calculation
"""

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt, nowdate, getdate, date_diff

PENALTY_RATES_PM = {
    "VAT": 0.00417, "WHT": 0.00417, "PAYE": 0.00833,
    "Pension": 0.02, "NHF": 0.00417, "NSITF": 0.00833,
    "ITF": 0.00833, "CIT": 0.00417,
}


class ComplianceLiabilityLedger(Document):

    def before_insert(self):
        self._set_ledger_key()
        self._set_period_dates()

    def validate(self):
        self._set_ledger_key()
        self._compute_totals()
        self._compute_status()
        self._compute_penalty()

    def before_save(self):
        self._compute_totals()
        self._compute_status()

    # ── Ledger Key ──────────────────────────────────────────────────────────
    def _set_ledger_key(self):
        if not self.ledger_key and self.obligation_type and self.period_label and self.company:
            company_code = self.company[:3].upper().replace(" ", "")
            self.ledger_key = f"{self.obligation_type.replace(' ', '_')}-{self.period_label}-{company_code}"

    def _set_period_dates(self):
        """Auto-populate period_start / period_end from period_label (MM-YYYY)."""
        if self.period_label and '-' in self.period_label and not self.period_start:
            try:
                parts = self.period_label.split('-')
                month, year = int(parts[0]), int(parts[1])
                import calendar
                last_day = calendar.monthrange(year, month)[1]
                self.period_start = f"{year:04d}-{month:02d}-01"
                self.period_end   = f"{year:04d}-{month:02d}-{last_day:02d}"
            except Exception:
                pass

    # ── Amounts ─────────────────────────────────────────────────────────────
    def _compute_totals(self):
        """
        total_liability = sum of source_lines.liability_amount
        total_allocated = sum of allocations.allocated_amount
        balance_due     = total_liability - total_allocated
        """
        self.total_liability = sum(flt(r.liability_amount) for r in (self.source_lines or []))
        self.total_allocated = sum(flt(r.allocated_amount) for r in (self.allocations or []))
        self.balance_due     = max(0, self.total_liability - self.total_allocated)

    # ── Status ───────────────────────────────────────────────────────────────
    def _compute_status(self):
        paid  = flt(self.total_allocated)
        total = flt(self.total_liability)
        due   = self.due_date

        if total <= 0:
            self.status = "Open"
            self.is_overdue = 0
            return

        if paid >= total:
            self.status    = "Fully Paid"
            self.is_overdue = 0
        elif paid > 0:
            self.status    = "Partially Paid"
            self.is_overdue = 1 if due and getdate(due) < getdate(nowdate()) else 0
        elif due and getdate(due) < getdate(nowdate()):
            self.status    = "Overdue"
            self.is_overdue = 1
        else:
            self.status    = "Open"
            self.is_overdue = 0

    # ── Penalty ──────────────────────────────────────────────────────────────
    def _compute_penalty(self):
        if self.status not in ("Overdue", "Partially Paid") or not self.due_date:
            return
        days_late    = max(0, date_diff(nowdate(), self.due_date))
        months_late  = days_late / 30.0
        monthly_rate = PENALTY_RATES_PM.get(self.obligation_type, 0.00417)
        self.penalty_amount = round(flt(self.balance_due) * monthly_rate * months_late, 2)

    # ── Public API ───────────────────────────────────────────────────────────
    def add_source_line(self, source_doctype, source_document, posting_date,
                        gross_amount, liability_amount, rate_applied=0, remarks=""):
        """Add a source transaction line. Deduplicates by source_document."""
        existing = {r.source_document for r in (self.source_lines or [])}
        if source_document not in existing:
            self.append("source_lines", {
                "source_doctype":    source_doctype,
                "source_document":   source_document,
                "posting_date":      posting_date,
                "gross_amount":      flt(gross_amount),
                "liability_amount":  flt(liability_amount),
                "rate_applied":      flt(rate_applied),
                "remarks":           remarks,
            })

    def apply_payment(self, payment_reference, payments_doc=None,
                      allocated_amount=0, allocation_method="Auto FIFO",
                      period_label=None):
        """Record a payment allocation. Updates totals and status."""
        self.append("allocations", {
            "payment_reference":          payment_reference,
            "payments_doc":               payments_doc or "",
            "obligation_type":            self.obligation_type,
            "period_label":               period_label or self.period_label,
            "allocated_amount":           flt(allocated_amount),
            "allocation_method":          allocation_method,
            "allocation_date":            nowdate(),
            "compliance_liability_ledger": self.name,
        })
        self._compute_totals()
        self._compute_status()
        self.last_reconciled_on = frappe.utils.now()
        self.save(ignore_permissions=True)
