# Copyright (c) 2026, Value Impacts Consulting
import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import nowdate, getdate

class CompliancePeriod(Document):
    def validate(self):
        if self.start_date and self.end_date:
            if getdate(self.end_date) < getdate(self.start_date):
                frappe.throw(_("End Date cannot be before Start Date."))

    def close_period(self):
        """Lock the period — no new CLL entries should be created."""
        self.db_set("is_closed", 1)
        self.db_set("locked_on", frappe.utils.now())
        frappe.msgprint(_("Period {0} is now closed.").format(self.period_label), indicator="green")
