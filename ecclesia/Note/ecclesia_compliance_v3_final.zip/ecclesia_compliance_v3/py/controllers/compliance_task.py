# Copyright (c) 2026, Value Impacts Consulting
import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import getdate, nowdate

class ComplianceTask(Document):
    def validate(self):
        if self.target_completion and getdate(self.target_completion) < getdate(nowdate()):
            if self.status not in ("Completed","Cancelled"):
                self.status = "Delayed"

    def on_submit(self):
        self.db_set("status", "In Progress")
