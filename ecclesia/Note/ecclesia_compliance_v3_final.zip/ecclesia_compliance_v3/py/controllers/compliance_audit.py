# Copyright (c) 2026, Value Impacts Consulting
import frappe
from frappe import _
from frappe.model.document import Document

class ComplianceAudit(Document):
    def validate(self):
        self._tally_findings()

    def on_submit(self):
        self.db_set("closure_status", "In Progress")
        self._notify_if_critical()

    def _tally_findings(self):
        findings = self.findings or []
        self.total_findings    = len(findings)
        self.critical_findings = sum(1 for f in findings if f.severity == "Critical")
        total = len(findings)
        resolved = sum(1 for f in findings if f.status in ("Resolved","Accepted Risk"))
        self.compliance_score = round(resolved / total * 100, 1) if total else 100.0

    def _notify_if_critical(self):
        if not self.critical_findings:
            return
        managers = frappe.db.get_all("Has Role", filters={"role":"Accounts Manager"}, fields=["parent"])
        emails = [frappe.db.get_value("User", m.parent, "email") for m in managers]
        emails = [e for e in emails if e]
        if emails:
            frappe.sendmail(recipients=emails,
                subject=f"Compliance Audit Completed: {self.audit_title} — {self.critical_findings} Critical",
                message=(f"Audit <b>{self.audit_title}</b> completed with {self.critical_findings} critical finding(s).<br>"
                         f"Compliance Score: {self.compliance_score}%<br>"
                         f"<a href='/Form/Compliance Audit/{self.name}'>Review Audit</a>"))
