# Copyright (c) 2026, Value Impacts Consulting
import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt, getdate, nowdate

class ComplianceFiling(Document):

    def validate(self):
        if not self.filing_title:
            self.filing_title = f"{self.obligation_type} — {self.fiscal_period} — {self.company}"
        self._check_late_filing()
        self._sync_from_cll()

    def on_submit(self):
        self.db_set("filing_status", "Filed")
        self._update_calendar_line()
        if self.late_filing_flag:
            self._raise_exception()

    def _check_late_filing(self):
        if self.filing_date and self.due_date:
            self.late_filing_flag = 1 if getdate(self.filing_date) > getdate(self.due_date) else 0

    def _sync_from_cll(self):
        if self.compliance_liability and not self.amount_assessed:
            vals = frappe.db.get_value("Compliance Liability Ledger", self.compliance_liability,
                                        ["total_liability","balance_due","due_date"], as_dict=True)
            if vals:
                self.amount_assessed = vals.total_liability
                if not self.due_date: self.due_date = vals.due_date

    def _update_calendar_line(self):
        if self.calendar_line:
            frappe.db.set_value("Compliance Calendar Line", self.calendar_line, {
                "status": "Filed",
                "filing_reference": self.name
            }, update_modified=False)

    def _raise_exception(self):
        if not frappe.db.exists("Compliance Exception", {"related_filing": self.name}):
            exc = frappe.new_doc("Compliance Exception")
            exc.exception_title = f"Late Filing: {self.filing_title}"
            exc.exception_type  = "Filing Rejection"
            exc.obligation_type = self.obligation_type
            exc.incident_date   = self.filing_date or nowdate()
            exc.related_filing  = self.name
            exc.description     = (f"{self.obligation_type} for {self.fiscal_period} filed on "
                                   f"{self.filing_date} — due date was {self.due_date}.")
            exc.status = "Open"
            exc.insert(ignore_permissions=True)
