# Copyright (c) 2026, Value Impacts Consulting
# Compliance Rule Controller
import frappe
from frappe import _
from frappe.model.document import Document

class ComplianceRule(Document):
    def validate(self):
        if self.due_day and not (1 <= int(self.due_day) <= 31):
            frappe.throw(_("Due Day must be between 1 and 31."))
        if not self.active:
            frappe.msgprint(_("This rule is inactive and will not generate liabilities."), indicator="orange")

    def get_due_date(self, period_label):
        """
        Compute due date for a given period (MM-YYYY) based on rule configuration.
        Returns date string YYYY-MM-DD.
        """
        try:
            month, year = int(period_label.split('-')[0]), int(period_label.split('-')[1])
        except Exception:
            return None
        offset = int(self.due_month_offset or 1)
        day    = int(self.due_day or 21)
        target_month = month + offset
        target_year  = year
        if target_month > 12:
            target_month -= 12
            target_year  += 1
        import calendar
        max_day = calendar.monthrange(target_year, target_month)[1]
        day = min(day, max_day)
        return f"{target_year:04d}-{target_month:02d}-{day:02d}"
