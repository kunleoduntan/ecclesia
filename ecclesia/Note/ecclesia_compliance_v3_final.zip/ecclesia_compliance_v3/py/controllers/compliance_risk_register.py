# Copyright (c) 2026, Value Impacts Consulting
import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt

class ComplianceRiskRegister(Document):
    def validate(self):
        self._score_all_risks()
        self._compute_summary()

    def on_submit(self):
        self.db_set("risk_status", "Open")

    def _score_all_risks(self):
        for r in (self.risk_items or []):
            l = int(r.likelihood or 1)
            i = int(r.impact or 1)
            r.risk_score = l * i
            if r.risk_score >= 20:   r.risk_level = "Critical"
            elif r.risk_score >= 12: r.risk_level = "High"
            elif r.risk_score >= 6:  r.risk_level = "Medium"
            else:                    r.risk_level = "Low"

    def _compute_summary(self):
        items = self.risk_items or []
        self.critical_count = sum(1 for r in items if r.risk_level == "Critical")
        self.high_count     = sum(1 for r in items if r.risk_level == "High")
        self.medium_count   = sum(1 for r in items if r.risk_level == "Medium")
        if items:
            self.overall_risk_score = round(sum(r.risk_score for r in items) / len(items), 1)
        levels = [r.risk_level for r in items]
        if "Critical" in levels:    self.overall_risk_level = "Critical"
        elif "High" in levels:      self.overall_risk_level = "High"
        elif "Medium" in levels:    self.overall_risk_level = "Medium"
        else:                       self.overall_risk_level = "Low"
